package com.edubridge.onlineshop;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.edubridge.onlineshop.entities.Login;
import com.edubridge.onlineshop.entities.Register;
import com.edubridge.onlineshop.repository.LoginRepository;
import com.edubridge.onlineshop.repository.RegisterRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)

@Rollback(false)

public class RepositoryTests {
	@Autowired
	private TestEntityManager testEntityManager;
	
	@Autowired
	LoginRepository loginRespository;
	
	@Autowired
	RegisterRepository registerRepository;
	
	@Test
	public void testCreateLogin() {
	    Login login = new Login();
	    login.setPassword("Vaithi");
	    login.setUsername("Raina");
	    Login savedLogin = loginRespository.save(login);
	     
	}
	@Test
	public void testCreateRegister() {
	    Register register = new Register();
	    
	    register.setFirstName("ajith");
	    register.setLastName("A");
	    register.setGender("male");
	    register.setAge(25);
	    register.setPhoneNumber(98765432);
	    register.setMailid("ajith@gmail.com");
	    Register savedRegister = registerRepository.save(register);

	}
}
