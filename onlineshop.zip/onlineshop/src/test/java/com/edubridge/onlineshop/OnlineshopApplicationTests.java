package com.edubridge.onlineshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
