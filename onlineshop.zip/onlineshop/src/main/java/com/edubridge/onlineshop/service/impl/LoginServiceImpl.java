package com.edubridge.onlineshop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.onlineshop.entities.Login;
import com.edubridge.onlineshop.repository.LoginRepository;
import com.edubridge.onlineshop.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService  {

	@Autowired
	LoginRepository loginRepo;

	@Override
	public Login saveLogin(Login login) {
		
		return loginRepo.save(login);
	}

	@Override
	public List<Login> getAllLogin() {
		
		return loginRepo.findAll();
	}
	
	
	
	
}
