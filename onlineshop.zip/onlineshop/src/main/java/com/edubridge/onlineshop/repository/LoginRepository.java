package com.edubridge.onlineshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.onlineshop.entities.Login;

@Repository
public interface LoginRepository extends JpaRepository<Login, Integer>{

}
