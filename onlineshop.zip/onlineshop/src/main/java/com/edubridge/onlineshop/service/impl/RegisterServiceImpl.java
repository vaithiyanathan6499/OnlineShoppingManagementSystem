package com.edubridge.onlineshop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.edubridge.onlineshop.entities.Register;
import com.edubridge.onlineshop.repository.RegisterRepository;
import com.edubridge.onlineshop.service.RegisterService;

@Service
public class RegisterServiceImpl implements RegisterService {
	
	@Autowired
	RegisterRepository registerRepo;

	@Override
	public Register saveRegister(Register register) {
		
		return registerRepo.save(register);
	}

	@Override
	public List<Register> getAllregisterItems() {
		
		return registerRepo.findAll();
	}

	@Override 
	public Register getRegisterById(int registerId) {
		return registerRepo.findById(registerId).get();
	}
	
	@Override
	public void deleteregister(int registerId) {
		registerRepo.deleteById(registerId);
	}
    @Override
    public Register updateRegister(int registerId, Register register) {
    	Register d1= getRegisterById(registerId);
    	d1.setPhoneNumber(register.getPhoneNumber());
    	return registerRepo.save(d1);
    }
}


	
