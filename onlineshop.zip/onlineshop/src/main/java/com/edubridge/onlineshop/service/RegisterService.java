package com.edubridge.onlineshop.service;

import java.util.List;



import com.edubridge.onlineshop.entities.Register;

public interface RegisterService {

	public Register saveRegister(Register register);
	public List<Register> getAllregisterItems();
	public void deleteregister(int registerId);
	public Register getRegisterById(int registerId);
	public Register updateRegister(int registerId,Register register);
}

