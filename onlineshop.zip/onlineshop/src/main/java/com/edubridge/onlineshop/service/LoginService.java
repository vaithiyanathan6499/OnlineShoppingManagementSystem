package com.edubridge.onlineshop.service;

import java.util.List;

import com.edubridge.onlineshop.entities.Login;

public interface LoginService {

	public Login saveLogin(Login login);
	public List<Login> getAllLogin();
}
