package com.edubridge.onlineshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.onlineshop.entities.Register;
import com.edubridge.onlineshop.service.RegisterService;

@RestController
public class RegisterController{
	
	@Autowired
	
	RegisterService registerservice;
	@PostMapping("/register/add")
	public Register saveRegister (@RequestBody Register register) {
		System.out.println(register);
		return registerservice.saveRegister(register);
		
	}
	@GetMapping("/register/registeritems")
	public List<Register> getAllRegister(){
	return registerservice.getAllregisterItems();
	}
	
	@DeleteMapping("/register/{registerId}")
	public String deleteRegister(@PathVariable int registerId) {
		registerservice.deleteregister(registerId);
		return "Delete successfully";
	}
	@PutMapping("/register/{id}")
	public ResponseEntity <Register> updateProduct (@PathVariable(value ="id") int registerId,@RequestBody Register register){
		Register updateProduct =registerservice.updateRegister(registerId,register);
		return ResponseEntity.ok(updateProduct);
	}
	

}